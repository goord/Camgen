//
// This file is part of the CAMGEN library.
// Copyright (C) 2013 Gijs van den Oord.
// CAMGEN is licensed under the GNU GPL, version 2,
// see COPYING for details.
//

#ifndef CAMGEN_TENSOR_H_
#define CAMGEN_TENSOR_H_

#include <Camgen/tens_it.h>

/* Inlusion of the tensor class and its iterators...*/

#endif /*CAMGEN_TENSOR_H_*/

